import React from "react";

const About = () =>{
    return(
        <div>
            <h2> I am from About</h2>
        </div>
    )
}

export default About;