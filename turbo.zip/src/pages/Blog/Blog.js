import React from 'react';

const Blog = () => {
    return (
        <div>
            <h2>Blog</h2>
        </div>
    );
};

export default Blog;